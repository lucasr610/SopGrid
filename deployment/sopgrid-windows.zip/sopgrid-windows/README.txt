================================================================
           SOPGRID WINDOWS - COMPLETE STANDALONE PACKAGE
================================================================

QUICK INSTALLATION (RECOMMENDED):
---------------------------------
1. Double-click SETUP.bat
2. Wait for installation to complete
3. SOPGRID will start automatically

The SETUP.bat will:
  - Check for Node.js installation
  - Configure environment variables
  - Install all dependencies
  - Setup database connection
  - Create desktop shortcut
  - Start SOPGRID

MANUAL INSTALLATION:
--------------------
If automatic setup fails:
1. Install Node.js from https://nodejs.org (LTS version)
2. Open Command Prompt in this folder
3. Run: npm install
4. Rename sopgrid-config.ini to .env
5. Run: npm run dev

ACCESS SOPGRID:
--------------
Browser: http://localhost:5000
Default Port: 5000 (change in .env if needed)

FILES INCLUDED:
--------------
✓ Complete SOPGRID source code
✓ MongoDB certificates (./server/certs/)
✓ Pre-configured API keys
✓ All dependencies listed
✓ Docker support files

TROUBLESHOOTING:
---------------
- Port conflict: Change PORT in .env file
- Permission errors: Run as Administrator
- Missing Node.js: Install from nodejs.org
- Firewall blocking: Allow Node.js through Windows Firewall

SECURITY NOTE:
-------------
This package contains test API keys. 
Change them before production use!

================================================================
